function logout()
 {window.location.href = "logout.php";
 }
