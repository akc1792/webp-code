<?php
  session_start();
  if(isset($_COOKIE["username"]))
   {$_SESSION['loggedin'] = true;
    $_SESSION['username'] = $_COOKIE['username'];
    $_SESSION['password'] = $_COOKIE['password'];
    header('location: PHP_Exercise2_message.php');
   }
  else if(isset($_SESSION['loggedin']))
   {header('location: PHP_Exercise2_message.php');
   }
?>

<!DOCTYPE HTML>
<html>
<head>
<title>PHP</title>
</head>

<body>
<h1>LOGIN</h1>

<form method="post" action="PHP_Exercise2_submit.php">
<input type="text" name="username" placeholder="Username" required="true"/><br/><br/>

<input type="password" name="password" placeholder="Password" required="true"/><br/><br/>

<input type="checkbox" name="remember"/> Remember Me <br/><br/>

<input type="submit" value="Login"/>
</form>

</body>
</html>
