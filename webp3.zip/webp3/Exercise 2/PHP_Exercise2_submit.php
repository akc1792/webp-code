<?php
  session_start();
  $_SESSION['loggedin'] = true;
  $_SESSION['username'] = $_POST['username'];
  $_SESSION['password'] = $_POST['password'];
  if($_POST['remember'] == 'on')
   {setcookie("username", $_POST['username'], time() + (86400 * 30));
    setcookie("password", $_POST['password'], time() + (86400 * 30));
   }
  header('location: PHP_Exercise2.php');
?>
