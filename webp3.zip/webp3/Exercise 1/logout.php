<?php
  session_start();
  session_unset();
  session_destroy();
  header('location: PHP_Exercise1_message.php');
?>
