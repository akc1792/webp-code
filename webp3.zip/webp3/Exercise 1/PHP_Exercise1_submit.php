<?php
  session_start();
  $_SESSION['loggedin'] = true;
  $_SESSION['username'] = $_POST['username'];
  $_SESSION['password'] = $_POST['password'];
  header('location: PHP_Exercise1.php');
?>
