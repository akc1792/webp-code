<?php
  session_start();
  if(!isset($_SESSION['loggedin']))
   {header('location: PHP_Exercise1.php');
   }
?>

<!DOCTYPE HTML>
<html>
<head>
<title>PHP</title>
</head>

<body>

<p>Welcome <?php echo $_SESSION['username']; ?></p>

<button onclick="logout();">Log Out</button>

<script src="PHP_Exercise1.js" text="text/javascript"></script>

</body>
</html>
