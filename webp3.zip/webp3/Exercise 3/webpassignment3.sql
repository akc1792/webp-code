-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 13, 2018 at 12:19 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webpassignment3`
--

-- --------------------------------------------------------

--
-- Table structure for table `country_state`
--

DROP TABLE IF EXISTS `country_state`;
CREATE TABLE IF NOT EXISTS `country_state` (
  `Country` varchar(45) NOT NULL,
  `State` varchar(45) NOT NULL,
  PRIMARY KEY (`State`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country_state`
--

INSERT INTO `country_state` (`Country`, `State`) VALUES
('India', 'West Bengal'),
('India', 'Maharashtra'),
('India', 'Kerala'),
('India', 'Andhra Pradesh'),
('India', 'Arunachal Pradesh'),
('India', 'Assam'),
('India', 'Bihar'),
('India', 'Uttar Pradesh'),
('USA', 'Alabama'),
('USA', 'Alaska'),
('USA', 'Arizona'),
('USA', 'California'),
('USA', 'Georgia'),
('USA', 'Illinois'),
('USA', 'Massachusetts'),
('USA', 'New York'),
('Australia', 'New South Wales'),
('Australia', 'Queensland'),
('Australia', 'South Australia'),
('Australia', 'Tasmania'),
('Australia', 'Victoria'),
('Australia', 'Western Australia'),
('Australia', 'Northern Territory'),
('Canada', 'Ontario'),
('Canada', 'Quebec'),
('Canada', 'Nova Scotia'),
('Canada', 'New Brunswick'),
('Canada', 'Manitoba'),
('Canada', 'British Columbia'),
('Canada', 'Alberta');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
