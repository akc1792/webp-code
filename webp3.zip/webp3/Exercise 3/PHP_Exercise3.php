<?php
  $con = mysqli_connect("localhost", "root", "", "WebPAssignment3") or die(mysqli_error($con));
  $select_query = "SELECT State FROM Country_State WHERE Country = '".$_GET['country']."'";
  $select_result = mysqli_query($con, $select_query);
  echo "<option>State:</option>";
  while ($row = mysqli_fetch_array($select_result))
   {echo "<option>".$row['State']."</option>";
   }
?>